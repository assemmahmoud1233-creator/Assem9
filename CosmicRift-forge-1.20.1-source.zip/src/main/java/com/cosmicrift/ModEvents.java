package com.cosmicrift;

import net.minecraft.client.renderer.entity.EndermanRenderer;
import net.minecraft.client.renderer.entity.PhantomRenderer;
import net.minecraft.client.renderer.entity.VexRenderer;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

public class ModEvents {

    @Mod.EventBusSubscriber(modid = CosmicRift.MODID, bus = Mod.EventBusSubscriber.Bus.MOD)
    public static class Common {
        @SubscribeEvent
        public static void attributes(EntityAttributeCreationEvent e) {
            e.put(ModEntities.COSMIC_WYRM.get(), com.cosmicrift.entity.CosmicWyrm.createAttributes().build());
            e.put(ModEntities.VOID_STALKER.get(), com.cosmicrift.entity.VoidStalker.createAttributes().build());
            e.put(ModEntities.WANDERING_SPIRIT.get(), com.cosmicrift.entity.WanderingSpirit.createAttributes().build());
        }

        @SubscribeEvent
        public static void tabs(BuildCreativeModeTabContentsEvent e) {
            if (e.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
                e.accept(ModEntities.WYRM_EGG.get());
                e.accept(ModEntities.STALKER_EGG.get());
                e.accept(ModEntities.SPIRIT_EGG.get());
            }
        }
    }

    @Mod.EventBusSubscriber(modid = CosmicRift.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
    public static class Client {
        @SubscribeEvent
        public static void renderers(EntityRenderersEvent.RegisterRenderers e) {
            e.registerEntityRenderer(ModEntities.COSMIC_WYRM.get(), PhantomRenderer::new);
            e.registerEntityRenderer(ModEntities.VOID_STALKER.get(), EndermanRenderer::new);
            e.registerEntityRenderer(ModEntities.WANDERING_SPIRIT.get(), VexRenderer::new);
        }
    }
}
