package com.cosmicrift.entity;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Vex;
import net.minecraft.world.level.Level;

/** Ghostly floating spirit that leaves a soul trail (vex-based). */
public class WanderingSpirit extends Vex {
    public WanderingSpirit(EntityType<? extends Vex> type, Level level) {
        super(type, level);
        this.xpReward = 15;
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Vex.createAttributes().add(Attributes.MAX_HEALTH, 40.0D);
    }

    @Override
    public void aiStep() {
        super.aiStep();
        if (this.level().isClientSide) {
            this.level().addParticle(ParticleTypes.SOUL,
                    this.getRandomX(0.6), this.getRandomY(), this.getRandomZ(0.6), 0, 0.03, 0);
            this.level().addParticle(ParticleTypes.ENCHANT,
                    this.getRandomX(1.0), this.getRandomY() + 0.4, this.getRandomZ(1.0), 0, 0.1, 0);
        }
    }
}
