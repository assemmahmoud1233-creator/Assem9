package com.cosmicrift.entity;

import javax.annotation.Nullable;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.monster.Phantom;
import net.minecraft.world.level.Level;

/** Giant glowing sky serpent (phantom-based). */
public class CosmicWyrm extends Phantom {
    public CosmicWyrm(EntityType<? extends Phantom> type, Level level) {
        super(type, level);
        this.xpReward = 50;
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 80.0D)
                .add(Attributes.ATTACK_DAMAGE, 8.0D)
                .add(Attributes.FOLLOW_RANGE, 64.0D);
    }

    @Override
    public SpawnGroupData finalizeSpawn(ServerLevelAccessor level, DifficultyInstance diff, MobSpawnType reason,
                                        @Nullable SpawnGroupData data, @Nullable CompoundTag tag) {
        SpawnGroupData d = super.finalizeSpawn(level, diff, reason, data, tag);
        this.setPhantomSize(6);
        this.setHealth(this.getMaxHealth());
        return d;
    }

    @Override
    public void aiStep() {
        super.aiStep();
        if (this.level().isClientSide) {
            for (int i = 0; i < 3; i++) {
                this.level().addParticle(ParticleTypes.END_ROD,
                        this.getRandomX(1.6), this.getRandomY(), this.getRandomZ(1.6), 0, -0.02, 0);
            }
            this.level().addParticle(ParticleTypes.REVERSE_PORTAL,
                    this.getRandomX(1.2), this.getRandomY(), this.getRandomZ(1.2), 0, 0, 0);
        }
    }
}
