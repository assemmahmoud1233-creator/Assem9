package com.cosmicrift;

import com.cosmicrift.entity.CosmicWyrm;
import com.cosmicrift.entity.VoidStalker;
import com.cosmicrift.entity.WanderingSpirit;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.item.Item;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, CosmicRift.MODID);
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, CosmicRift.MODID);

    public static final RegistryObject<EntityType<CosmicWyrm>> COSMIC_WYRM = ENTITIES.register("cosmic_wyrm",
            () -> EntityType.Builder.of(CosmicWyrm::new, MobCategory.MONSTER)
                    .sized(0.9f, 0.5f).fireImmune().clientTrackingRange(10).build("cosmic_wyrm"));

    public static final RegistryObject<EntityType<VoidStalker>> VOID_STALKER = ENTITIES.register("void_stalker",
            () -> EntityType.Builder.of(VoidStalker::new, MobCategory.MONSTER)
                    .sized(0.6f, 2.9f).clientTrackingRange(8).build("void_stalker"));

    public static final RegistryObject<EntityType<WanderingSpirit>> WANDERING_SPIRIT = ENTITIES.register("wandering_spirit",
            () -> EntityType.Builder.of(WanderingSpirit::new, MobCategory.MONSTER)
                    .sized(0.4f, 0.8f).fireImmune().clientTrackingRange(8).build("wandering_spirit"));

    public static final RegistryObject<Item> WYRM_EGG = ITEMS.register("cosmic_wyrm_spawn_egg",
            () -> new ForgeSpawnEggItem(COSMIC_WYRM, 0x1b0a4d, 0x00e5ff, new Item.Properties()));
    public static final RegistryObject<Item> STALKER_EGG = ITEMS.register("void_stalker_spawn_egg",
            () -> new ForgeSpawnEggItem(VOID_STALKER, 0x000000, 0xb000ff, new Item.Properties()));
    public static final RegistryObject<Item> SPIRIT_EGG = ITEMS.register("wandering_spirit_spawn_egg",
            () -> new ForgeSpawnEggItem(WANDERING_SPIRIT, 0x9fffe0, 0x3a2a7a, new Item.Properties()));
}
