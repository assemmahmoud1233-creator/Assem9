package com.cosmicrift;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.commands.Commands;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.projectile.LargeFireball;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = CosmicRift.MODID)
public class CosmicEvents {

    private static class Rift {
        final ServerLevel level; final BlockPos pos; int ticks = 200;
        Rift(ServerLevel l, BlockPos p) { level = l; pos = p; }
    }
    private static final List<Rift> RIFTS = new ArrayList<>();

    @SubscribeEvent
    public static void onTick(TickEvent.LevelTickEvent e) {
        if (e.phase != TickEvent.Phase.END || !(e.level instanceof ServerLevel level)) return;
        if (level.dimension() != Level.OVERWORLD) return;

        Iterator<Rift> it = RIFTS.iterator();
        while (it.hasNext()) {
            Rift r = it.next();
            if (r.level != level) continue;
            tickRift(r);
            if (--r.ticks <= 0) { closeRift(r); it.remove(); }
        }

        // Natural random events: checked once a minute, 25% chance.
        if (level.getGameTime() % 1200 != 0) return;
        if (level.random.nextFloat() > 0.25f) return;
        List<ServerPlayer> players = level.players();
        if (players.isEmpty()) return;
        ServerPlayer p = players.get(level.random.nextInt(players.size()));
        switch (level.random.nextInt(3)) {
            case 0 -> meteorShower(level, p);
            case 1 -> supernova(level, p);
            default -> rift(level, p);
        }
    }

    @SubscribeEvent
    public static void commands(RegisterCommandsEvent e) {
        e.getDispatcher().register(Commands.literal("cosmic").requires(s -> s.hasPermission(2))
                .then(Commands.literal("meteor").executes(c -> {
                    meteorShower(c.getSource().getLevel(), c.getSource().getPlayerOrException()); return 1; }))
                .then(Commands.literal("supernova").executes(c -> {
                    supernova(c.getSource().getLevel(), c.getSource().getPlayerOrException()); return 1; }))
                .then(Commands.literal("rift").executes(c -> {
                    rift(c.getSource().getLevel(), c.getSource().getPlayerOrException()); return 1; })));
    }

    private static void announce(ServerLevel level, String text, ChatFormatting color) {
        level.getServer().getPlayerList().broadcastSystemMessage(Component.literal(text).withStyle(color), false);
    }

    public static void meteorShower(ServerLevel level, ServerPlayer p) {
        announce(level, "☄ مطر نيازك فوق الرؤوس! احتمي!", ChatFormatting.GOLD);
        RandomSource r = level.random;
        for (int i = 0; i < 14; i++) {
            LargeFireball fb = EntityType.FIREBALL.create(level);
            if (fb == null) continue;
            fb.moveTo(p.getX() + (r.nextDouble() - 0.5) * 60, p.getY() + 22 + r.nextDouble() * 14,
                    p.getZ() + (r.nextDouble() - 0.5) * 60);
            fb.setDeltaMovement((r.nextDouble() - 0.5) * 0.5, -2.2, (r.nextDouble() - 0.5) * 0.5);
            level.addFreshEntity(fb);
        }
    }

    public static void supernova(ServerLevel level, ServerPlayer p) {
        announce(level, "✦ سوبرنوفا! السما اتنورت!", ChatFormatting.AQUA);
        Vec3 c = p.position().add(0, 28, 0);
        level.playSound(null, p.blockPosition(), SoundEvents.LIGHTNING_BOLT_THUNDER, SoundSource.AMBIENT, 6f, 0.5f);
        level.sendParticles(ParticleTypes.FLASH, c.x, c.y, c.z, 3, 0, 0, 0, 0);
        level.sendParticles(ParticleTypes.EXPLOSION_EMITTER, c.x, c.y, c.z, 3, 2, 2, 2, 0);
        for (int i = 0; i < 300; i++) {
            double a = level.random.nextDouble() * Math.PI * 2;
            double up = (level.random.nextDouble() - 0.5) * 0.8;
            level.sendParticles(ParticleTypes.END_ROD, c.x, c.y, c.z, 0, Math.cos(a), up, Math.sin(a), 1.4);
        }
        for (Monster m : level.getEntitiesOfClass(Monster.class, p.getBoundingBox().inflate(48))) {
            m.addEffect(new MobEffectInstance(MobEffects.GLOWING, 600));
        }
        for (ServerPlayer sp : level.players()) {
            if (sp.distanceToSqr(p) < 64 * 64) sp.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 400));
        }
    }

    public static void rift(ServerLevel level, ServerPlayer p) {
        announce(level, "✧ شق كوني بيتفتح قريب منك...", ChatFormatting.LIGHT_PURPLE);
        RandomSource r = level.random;
        double a = r.nextDouble() * Math.PI * 2;
        double d = 14 + r.nextDouble() * 8;
        BlockPos base = p.blockPosition().offset((int) (Math.cos(a) * d), 0, (int) (Math.sin(a) * d));
        BlockPos ground = level.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, base);
        level.playSound(null, ground, SoundEvents.PORTAL_TRIGGER, SoundSource.AMBIENT, 3f, 0.6f);
        RIFTS.add(new Rift(level, ground));
    }

    private static void tickRift(Rift r) {
        double t = r.level.getGameTime() * 0.3;
        double cx = r.pos.getX() + 0.5, cy = r.pos.getY() + 3.5, cz = r.pos.getZ() + 0.5;
        for (int i = 0; i < 4; i++) {
            double a = t + i * (Math.PI / 2);
            double rad = 3.0 + Math.sin(t * 0.5);
            r.level.sendParticles(ParticleTypes.REVERSE_PORTAL, cx + Math.cos(a) * rad, cy + Math.sin(a * 2), cz + Math.sin(a) * rad, 1, 0, 0, 0, 0.02);
        }
        r.level.sendParticles(ParticleTypes.END_ROD, cx, cy, cz, 2, 0.3, 0.6, 0.3, 0.01);
    }

    private static void closeRift(Rift r) {
        ServerLevel level = r.level;
        LightningBolt bolt = EntityType.LIGHTNING_BOLT.create(level);
        if (bolt != null) {
            bolt.moveTo(Vec3.atBottomCenterOf(r.pos));
            bolt.setVisualOnly(true);
            level.addFreshEntity(bolt);
        }
        level.sendParticles(ParticleTypes.EXPLOSION_EMITTER, r.pos.getX() + 0.5, r.pos.getY() + 3, r.pos.getZ() + 0.5, 1, 0, 0, 0, 0);
        int roll = level.random.nextInt(10);
        if (roll < 3) {
            ModEntities.COSMIC_WYRM.get().spawn(level, r.pos.above(6), MobSpawnType.EVENT);
        } else if (roll < 7) {
            for (int i = 0; i < 2; i++) ModEntities.VOID_STALKER.get().spawn(level, r.pos.offset(i * 2, 0, 0), MobSpawnType.EVENT);
        } else {
            for (int i = 0; i < 3; i++) ModEntities.WANDERING_SPIRIT.get().spawn(level, r.pos.above(3 + i), MobSpawnType.EVENT);
        }
    }
}
